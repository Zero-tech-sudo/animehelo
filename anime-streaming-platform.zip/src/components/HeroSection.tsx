import { Play, Info } from 'lucide-react';
import { Link } from 'react-router-dom';
import { Anime } from '../types';

interface HeroSectionProps {
  featuredAnime: Anime;
}

export default function HeroSection({ featuredAnime }: HeroSectionProps) {
  return (
    <div className="relative w-full h-[500px] md:h-[600px] overflow-hidden">
      {/* Background Image with Gradient Overlay */}
      <div className="absolute inset-0">
        <img
          src={featuredAnime.bannerImage}
          alt={featuredAnime.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/70 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-dark-950 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="relative h-full container-custom flex items-center">
        <div className="max-w-2xl space-y-6">
          {/* Title */}
          <h1 className="font-display font-bold text-4xl md:text-6xl text-white leading-tight">
            {featuredAnime.title}
          </h1>

          {/* Metadata */}
          <div className="flex flex-wrap items-center gap-3 text-sm md:text-base">
            <span className="px-3 py-1 bg-primary-600 text-white rounded-md font-medium">
              {featuredAnime.type}
            </span>
            <span className="text-dark-200">{featuredAnime.releaseYear}</span>
            <span className="text-dark-200">•</span>
            <span className="text-dark-200">{featuredAnime.episodeCount} Episodes</span>
            <span className="text-dark-200">•</span>
            <span className="text-dark-200">{featuredAnime.status}</span>
          </div>

          {/* Genres */}
          <div className="flex flex-wrap gap-2">
            {featuredAnime.genres.map((genre) => (
              <span
                key={genre}
                className="px-3 py-1 bg-dark-800/80 backdrop-blur-sm text-dark-200 rounded-md text-sm"
              >
                {genre}
              </span>
            ))}
          </div>

          {/* Synopsis */}
          <p className="text-dark-200 text-base md:text-lg line-clamp-3 leading-relaxed">
            {featuredAnime.fullSynopsis}
          </p>

          {/* Action Buttons */}
          <div className="flex flex-wrap gap-4 pt-2">
            <Link
              to={`/anime/${featuredAnime.id}`}
              className="btn-primary flex items-center space-x-2 text-lg px-8"
            >
              <Play size={20} fill="currentColor" />
              <span>Watch Now</span>
            </Link>
            
            <Link
              to={`/anime/${featuredAnime.id}`}
              className="btn-secondary flex items-center space-x-2 text-lg px-8"
            >
              <Info size={20} />
              <span>More Info</span>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
