import { Link } from 'react-router-dom';
import { Anime } from '../types';
import { Play, Eye } from 'lucide-react';

interface AnimeCardProps {
  anime: Anime;
}

export default function AnimeCard({ anime }: AnimeCardProps) {
  return (
    <Link to={`/anime/${anime.id}`} className="group">
      <div className="card overflow-hidden">
        {/* Poster Image */}
        <div className="relative aspect-[2/3] overflow-hidden bg-dark-800">
          <img
            src={anime.posterImage}
            alt={anime.title}
            className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
            loading="lazy"
          />
          
          {/* Overlay on Hover */}
          <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300">
            <div className="absolute bottom-0 left-0 right-0 p-4 space-y-2">
              <button className="w-full btn-primary flex items-center justify-center space-x-2">
                <Play size={18} fill="currentColor" />
                <span>Watch Now</span>
              </button>
            </div>
          </div>

          {/* Status Badge */}
          <div className="absolute top-2 left-2">
            <span className={`px-2 py-1 rounded text-xs font-medium ${
              anime.status === 'ongoing' 
                ? 'bg-green-500/90 text-white' 
                : anime.status === 'completed'
                ? 'bg-blue-500/90 text-white'
                : 'bg-orange-500/90 text-white'
            }`}>
              {anime.status === 'ongoing' ? 'Ongoing' : anime.status === 'completed' ? 'Completed' : 'Upcoming'}
            </span>
          </div>

          {/* Language Badges */}
          <div className="absolute top-2 right-2 flex gap-1">
            {anime.language.includes('sub') && (
              <span className="px-2 py-1 rounded text-xs font-medium bg-primary-600/90 text-white">
                SUB
              </span>
            )}
            {anime.language.includes('dub') && (
              <span className="px-2 py-1 rounded text-xs font-medium bg-purple-600/90 text-white">
                DUB
              </span>
            )}
          </div>
        </div>

        {/* Card Info */}
        <div className="p-4 space-y-2">
          <h3 className="font-semibold text-dark-50 line-clamp-2 group-hover:text-primary-400 transition-colors">
            {anime.title}
          </h3>
          
          <div className="flex items-center justify-between text-sm text-dark-400">
            <span>{anime.type} • {anime.releaseYear}</span>
            <div className="flex items-center space-x-1">
              <Eye size={14} />
              <span>{(anime.views / 1000).toFixed(0)}K</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-xs text-dark-500">
            <span>{anime.episodeCount} Episodes</span>
            <span>{anime.duration}min</span>
          </div>

          {/* Genres */}
          <div className="flex flex-wrap gap-1 pt-1">
            {anime.genres.slice(0, 3).map((genre) => (
              <span
                key={genre}
                className="px-2 py-0.5 bg-dark-800 text-dark-300 rounded text-xs"
              >
                {genre}
              </span>
            ))}
          </div>
        </div>
      </div>
    </Link>
  );
}
