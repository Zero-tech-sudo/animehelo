import { useSearchParams } from 'react-router-dom';
import { Search as SearchIcon } from 'lucide-react';
import AnimeCard from '../components/AnimeCard';
import { mockAnimeList } from '../data/mockData';

export default function SearchPage() {
  const [searchParams] = useSearchParams();
  const query = searchParams.get('q') || '';

  // Filter anime based on search query
  const searchResults = mockAnimeList.filter((anime) => {
    const searchLower = query.toLowerCase();
    return (
      anime.title.toLowerCase().includes(searchLower) ||
      anime.genres.some((genre) => genre.toLowerCase().includes(searchLower)) ||
      anime.synopsis.toLowerCase().includes(searchLower) ||
      anime.alternativeTitles?.some((title) => title.toLowerCase().includes(searchLower))
    );
  });

  return (
    <div className="min-h-screen py-8">
      <div className="container-custom">
        {/* Header */}
        <div className="mb-8">
          <h1 className="font-display font-bold text-3xl md:text-4xl text-dark-50 mb-2">
            Search Results
          </h1>
          {query && (
            <p className="text-dark-400">
              Showing results for: <span className="text-primary-400 font-medium">"{query}"</span>
            </p>
          )}
        </div>

        {/* Results */}
        {searchResults.length > 0 ? (
          <>
            <div className="mb-4 text-sm text-dark-400">
              {searchResults.length} anime found
            </div>
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {searchResults.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
            </div>
          </>
        ) : (
          <div className="text-center py-20">
            <SearchIcon size={48} className="mx-auto text-dark-600 mb-4" />
            <h3 className="text-xl font-semibold text-dark-300 mb-2">
              No results found
            </h3>
            <p className="text-dark-500">
              {query
                ? `We couldn't find any anime matching "${query}"`
                : 'Enter a search query to find anime'}
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
