import { useState } from 'react';
import { Filter, SlidersHorizontal } from 'lucide-react';
import AnimeCard from '../components/AnimeCard';
import { mockAnimeList, genres } from '../data/mockData';
import { Anime } from '../types';

export default function BrowsePage() {
  const [selectedGenres, setSelectedGenres] = useState<string[]>([]);
  const [selectedStatus, setSelectedStatus] = useState<Anime['status'] | 'all'>('all');
  const [selectedType, setSelectedType] = useState<Anime['type'] | 'all'>('all');
  const [sortBy, setSortBy] = useState<'popularity' | 'views' | 'recent' | 'title'>('popularity');
  const [showFilters, setShowFilters] = useState(false);

  // Filter and sort anime
  const filteredAnimes = mockAnimeList
    .filter((anime) => {
      if (selectedGenres.length > 0) {
        return selectedGenres.some((genre) => anime.genres.includes(genre));
      }
      return true;
    })
    .filter((anime) => selectedStatus === 'all' || anime.status === selectedStatus)
    .filter((anime) => selectedType === 'all' || anime.type === selectedType)
    .sort((a, b) => {
      switch (sortBy) {
        case 'popularity':
          return b.popularity - a.popularity;
        case 'views':
          return b.views - a.views;
        case 'recent':
          return new Date(b.lastUpdated).getTime() - new Date(a.lastUpdated).getTime();
        case 'title':
          return a.title.localeCompare(b.title);
        default:
          return 0;
      }
    });

  const toggleGenre = (genre: string) => {
    setSelectedGenres((prev) =>
      prev.includes(genre) ? prev.filter((g) => g !== genre) : [...prev, genre]
    );
  };

  return (
    <div className="min-h-screen py-8">
      <div className="container-custom">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <h1 className="font-display font-bold text-3xl md:text-4xl text-dark-50">
            Browse Anime
          </h1>
          
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="md:hidden btn-secondary flex items-center space-x-2"
          >
            <SlidersHorizontal size={18} />
            <span>Filters</span>
          </button>
        </div>

        <div className="flex flex-col md:flex-row gap-8">
          {/* Filters Sidebar */}
          <div className={`md:w-64 space-y-6 ${showFilters ? 'block' : 'hidden md:block'}`}>
            <div className="card p-6 space-y-6">
              {/* Sort By */}
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Sort By
                </label>
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="input-field"
                >
                  <option value="popularity">Popularity</option>
                  <option value="views">Most Viewed</option>
                  <option value="recent">Recently Updated</option>
                  <option value="title">Title (A-Z)</option>
                </select>
              </div>

              {/* Status Filter */}
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Status
                </label>
                <select
                  value={selectedStatus}
                  onChange={(e) => setSelectedStatus(e.target.value as any)}
                  className="input-field"
                >
                  <option value="all">All Status</option>
                  <option value="ongoing">Ongoing</option>
                  <option value="completed">Completed</option>
                  <option value="upcoming">Upcoming</option>
                </select>
              </div>

              {/* Type Filter */}
              <div>
                <label className="block text-sm font-medium text-dark-300 mb-2">
                  Type
                </label>
                <select
                  value={selectedType}
                  onChange={(e) => setSelectedType(e.target.value as any)}
                  className="input-field"
                >
                  <option value="all">All Types</option>
                  <option value="TV">TV Series</option>
                  <option value="Movie">Movie</option>
                  <option value="OVA">OVA</option>
                  <option value="ONA">ONA</option>
                  <option value="Special">Special</option>
                </select>
              </div>

              {/* Genre Filter */}
              <div>
                <div className="flex items-center justify-between mb-2">
                  <label className="block text-sm font-medium text-dark-300">
                    Genres
                  </label>
                  {selectedGenres.length > 0 && (
                    <button
                      onClick={() => setSelectedGenres([])}
                      className="text-xs text-primary-400 hover:text-primary-300"
                    >
                      Clear
                    </button>
                  )}
                </div>
                <div className="flex flex-wrap gap-2 max-h-64 overflow-y-auto">
                  {genres.map((genre) => (
                    <button
                      key={genre}
                      onClick={() => toggleGenre(genre)}
                      className={`px-3 py-1.5 rounded-md text-sm transition-colors ${
                        selectedGenres.includes(genre)
                          ? 'bg-primary-600 text-white'
                          : 'bg-dark-800 text-dark-300 hover:bg-dark-700'
                      }`}
                    >
                      {genre}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Anime Grid */}
          <div className="flex-1">
            <div className="mb-4 text-sm text-dark-400">
              {filteredAnimes.length} anime found
            </div>
            
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              {filteredAnimes.map((anime) => (
                <AnimeCard key={anime.id} anime={anime} />
              ))}
            </div>

            {filteredAnimes.length === 0 && (
              <div className="text-center py-20">
                <Filter size={48} className="mx-auto text-dark-600 mb-4" />
                <h3 className="text-xl font-semibold text-dark-300 mb-2">
                  No anime found
                </h3>
                <p className="text-dark-500">
                  Try adjusting your filters to see more results
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
