import { useParams, Link } from 'react-router-dom';
import { ChevronLeft, ChevronRight, Download, Settings } from 'lucide-react';
import { mockAnimeList, mockEpisodes } from '../data/mockData';
import { useState } from 'react';

export default function WatchPage() {
  const { id, episodeNumber } = useParams<{ id: string; episodeNumber: string }>();
  const anime = mockAnimeList.find((a) => a.id === id);
  const currentEpisodeNum = parseInt(episodeNumber || '1');
  const currentEpisode = mockEpisodes.find(
    (ep) => ep.animeId === id && ep.number === currentEpisodeNum
  );

  const [selectedQuality, setSelectedQuality] = useState('1080p');
  const [selectedLanguage, setSelectedLanguage] = useState<'sub' | 'dub'>('sub');

  if (!anime || !currentEpisode) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-dark-300 mb-4">Episode not found</h2>
          <Link to="/" className="btn-primary">
            Go Home
          </Link>
        </div>
      </div>
    );
  }

  const allEpisodes = mockEpisodes.filter((ep) => ep.animeId === id);
  const previousEpisode = allEpisodes.find((ep) => ep.number === currentEpisodeNum - 1);
  const nextEpisode = allEpisodes.find((ep) => ep.number === currentEpisodeNum + 1);

  return (
    <div className="min-h-screen bg-black">
      {/* Video Player Container */}
      <div className="w-full bg-black">
        <div className="container-custom">
          {/* Player */}
          <div className="relative aspect-video bg-dark-900 flex items-center justify-center">
            {/* Placeholder for video player */}
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center space-y-4">
                <div className="w-20 h-20 rounded-full bg-primary-600/20 flex items-center justify-center mx-auto">
                  <div className="w-0 h-0 border-l-[20px] border-l-primary-500 border-y-[12px] border-y-transparent ml-1" />
                </div>
                <p className="text-dark-400">Video player would render here</p>
                <p className="text-sm text-dark-500">
                  Quality: {selectedQuality} • {selectedLanguage.toUpperCase()}
                </p>
              </div>
            </div>

            {/* Episode Navigation Overlay */}
            <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-white font-semibold text-lg">
                    {anime.title} - Episode {currentEpisode.number}
                  </h2>
                  <p className="text-dark-300 text-sm">{currentEpisode.title}</p>
                </div>
                
                <div className="flex items-center space-x-2">
                  <button className="p-2 rounded bg-dark-800/80 hover:bg-dark-700 text-white transition-colors">
                    <Settings size={20} />
                  </button>
                  {currentEpisode.streamAssets[0]?.downloadable && (
                    <button className="p-2 rounded bg-dark-800/80 hover:bg-dark-700 text-white transition-colors">
                      <Download size={20} />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* Controls Below Player */}
          <div className="flex items-center justify-between py-4 border-b border-dark-800">
            <Link
              to={`/anime/${id}`}
              className="text-dark-400 hover:text-primary-400 transition-colors"
            >
              ← Back to {anime.title}
            </Link>

            <div className="flex items-center space-x-2">
              {previousEpisode && (
                <Link
                  to={`/watch/${id}/${previousEpisode.number}`}
                  className="btn-secondary flex items-center space-x-1 text-sm"
                >
                  <ChevronLeft size={16} />
                  <span>Previous</span>
                </Link>
              )}
              
              {nextEpisode && (
                <Link
                  to={`/watch/${id}/${nextEpisode.number}`}
                  className="btn-primary flex items-center space-x-1 text-sm"
                >
                  <span>Next</span>
                  <ChevronRight size={16} />
                </Link>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Episode Info and List */}
      <div className="container-custom py-8">
        <div className="grid lg:grid-cols-3 gap-8">
          {/* Episode Description */}
          <div className="lg:col-span-2 space-y-6">
            <div>
              <h3 className="font-display font-bold text-2xl text-white mb-4">
                Episode {currentEpisode.number}: {currentEpisode.title}
              </h3>
              {currentEpisode.synopsis && (
                <p className="text-dark-300 leading-relaxed">{currentEpisode.synopsis}</p>
              )}
            </div>

            {/* Quality & Language Selector */}
            <div className="card p-6">
              <h4 className="font-semibold text-white mb-4">Playback Options</h4>
              
              <div className="space-y-4">
                <div>
                  <label className="block text-sm text-dark-400 mb-2">Quality</label>
                  <div className="flex flex-wrap gap-2">
                    {currentEpisode.streamAssets.map((asset) => (
                      <button
                        key={asset.id}
                        onClick={() => setSelectedQuality(asset.quality)}
                        className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                          selectedQuality === asset.quality
                            ? 'bg-primary-600 text-white'
                            : 'bg-dark-800 text-dark-300 hover:bg-dark-700'
                        }`}
                      >
                        {asset.quality}
                      </button>
                    ))}
                  </div>
                </div>

                {anime.language.length > 1 && (
                  <div>
                    <label className="block text-sm text-dark-400 mb-2">Language</label>
                    <div className="flex gap-2">
                      {anime.language.map((lang) => (
                        <button
                          key={lang}
                          onClick={() => setSelectedLanguage(lang)}
                          className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                            selectedLanguage === lang
                              ? 'bg-primary-600 text-white'
                              : 'bg-dark-800 text-dark-300 hover:bg-dark-700'
                          }`}
                        >
                          {lang.toUpperCase()}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Episodes List Sidebar */}
          <div className="card p-6">
            <h4 className="font-semibold text-white mb-4">Episodes</h4>
            <div className="space-y-2 max-h-[600px] overflow-y-auto">
              {allEpisodes.map((episode) => (
                <Link
                  key={episode.id}
                  to={`/watch/${id}/${episode.number}`}
                  className={`block p-3 rounded-lg transition-colors ${
                    episode.number === currentEpisodeNum
                      ? 'bg-primary-600 text-white'
                      : 'bg-dark-800 text-dark-300 hover:bg-dark-700'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="font-medium">Episode {episode.number}</div>
                      <div className="text-sm opacity-80 line-clamp-1">{episode.title}</div>
                    </div>
                    <div className="text-xs opacity-60 ml-2">
                      {Math.floor(episode.duration / 60)}m
                    </div>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
