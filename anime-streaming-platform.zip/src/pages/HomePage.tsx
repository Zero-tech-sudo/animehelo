import HeroSection from '../components/HeroSection';
import AnimeRow from '../components/AnimeRow';
import { mockAnimeList } from '../data/mockData';

export default function HomePage() {
  // Featured anime for hero section
  const featuredAnime = mockAnimeList[0];

  // Filter animes for different sections
  const trendingAnimes = mockAnimeList.filter(a => a.popularity > 9000);
  const newEpisodes = mockAnimeList.filter(a => a.status === 'ongoing').slice(0, 6);
  const popularThisWeek = [...mockAnimeList].sort((a, b) => b.views - a.views).slice(0, 6);
  const actionAnimes = mockAnimeList.filter(a => a.genres.includes('Action')).slice(0, 6);
  const fantasyAnimes = mockAnimeList.filter(a => a.genres.includes('Fantasy')).slice(0, 6);

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <HeroSection featuredAnime={featuredAnime} />

      {/* Content Sections */}
      <div className="container-custom py-12 space-y-12">
        <AnimeRow title="Trending Now" animes={trendingAnimes} />
        <AnimeRow title="New Episodes" animes={newEpisodes} />
        <AnimeRow title="Popular This Week" animes={popularThisWeek} />
        <AnimeRow title="Action" animes={actionAnimes} />
        <AnimeRow title="Fantasy" animes={fantasyAnimes} />
      </div>
    </div>
  );
}
