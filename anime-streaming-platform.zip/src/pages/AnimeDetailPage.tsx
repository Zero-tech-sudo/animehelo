import { useParams, Link } from 'react-router-dom';
import { Play, Calendar, Film, Clock, Eye, Download } from 'lucide-react';
import { mockAnimeList, mockEpisodes } from '../data/mockData';
import AnimeCard from '../components/AnimeCard';

export default function AnimeDetailPage() {
  const { id } = useParams<{ id: string }>();
  const anime = mockAnimeList.find((a) => a.id === id);

  if (!anime) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-dark-300 mb-4">Anime not found</h2>
          <Link to="/" className="btn-primary">
            Go Home
          </Link>
        </div>
      </div>
    );
  }

  // Get episodes for this anime (filter by animeId)
  const episodes = mockEpisodes.filter((ep) => ep.animeId === anime.id);

  // Get related anime (same genre)
  const relatedAnimes = mockAnimeList
    .filter((a) => a.id !== anime.id && a.genres.some((g) => anime.genres.includes(g)))
    .slice(0, 6);

  return (
    <div className="min-h-screen">
      {/* Banner Section */}
      <div className="relative w-full h-[400px] md:h-[500px] overflow-hidden">
        <img
          src={anime.bannerImage}
          alt={anime.title}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-black/90 via-black/60 to-transparent" />
        <div className="absolute inset-0 bg-gradient-to-t from-dark-950 via-transparent to-transparent" />
      </div>

      {/* Content */}
      <div className="container-custom -mt-32 relative z-10 pb-12">
        <div className="flex flex-col md:flex-row gap-8">
          {/* Poster */}
          <div className="flex-shrink-0">
            <div className="w-48 md:w-64 card overflow-hidden">
              <img
                src={anime.posterImage}
                alt={anime.title}
                className="w-full h-auto"
              />
            </div>
          </div>

          {/* Info */}
          <div className="flex-1 space-y-6">
            {/* Title & Metadata */}
            <div>
              <h1 className="font-display font-bold text-3xl md:text-5xl text-white mb-4">
                {anime.title}
              </h1>
              
              {anime.alternativeTitles && anime.alternativeTitles.length > 0 && (
                <p className="text-dark-400 mb-4">
                  {anime.alternativeTitles.join(' • ')}
                </p>
              )}

              <div className="flex flex-wrap gap-2 mb-4">
                {anime.genres.map((genre) => (
                  <span
                    key={genre}
                    className="px-3 py-1 bg-dark-800 text-dark-200 rounded-md text-sm"
                  >
                    {genre}
                  </span>
                ))}
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                <div className="flex items-center space-x-2 text-dark-300">
                  <Calendar size={16} />
                  <span>{anime.releaseYear}</span>
                </div>
                <div className="flex items-center space-x-2 text-dark-300">
                  <Film size={16} />
                  <span>{anime.type}</span>
                </div>
                <div className="flex items-center space-x-2 text-dark-300">
                  <Clock size={16} />
                  <span>{anime.duration} min/ep</span>
                </div>
                <div className="flex items-center space-x-2 text-dark-300">
                  <Eye size={16} />
                  <span>{(anime.views / 1000).toFixed(0)}K views</span>
                </div>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex flex-wrap gap-4">
              {episodes.length > 0 && (
                <Link
                  to={`/watch/${anime.id}/1`}
                  className="btn-primary flex items-center space-x-2"
                >
                  <Play size={20} fill="currentColor" />
                  <span>Watch Episode 1</span>
                </Link>
              )}
              
              <button className="btn-secondary flex items-center space-x-2">
                <Download size={20} />
                <span>Download</span>
              </button>
            </div>

            {/* Synopsis */}
            <div>
              <h2 className="font-display font-bold text-2xl text-white mb-3">Synopsis</h2>
              <p className="text-dark-300 leading-relaxed">{anime.fullSynopsis}</p>
            </div>

            {/* Additional Info */}
            <div className="grid md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-dark-500">Studio:</span>
                <span className="text-dark-200 ml-2">{anime.studio}</span>
              </div>
              <div>
                <span className="text-dark-500">Status:</span>
                <span className="text-dark-200 ml-2 capitalize">{anime.status}</span>
              </div>
              <div>
                <span className="text-dark-500">Episodes:</span>
                <span className="text-dark-200 ml-2">{anime.episodeCount}</span>
              </div>
              <div>
                <span className="text-dark-500">Languages:</span>
                <span className="text-dark-200 ml-2">
                  {anime.language.map(l => l.toUpperCase()).join(', ')}
                </span>
              </div>
            </div>
          </div>
        </div>

        {/* Episodes List */}
        {episodes.length > 0 && (
          <div className="mt-12">
            <h2 className="font-display font-bold text-2xl text-white mb-6">Episodes</h2>
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {episodes.map((episode) => (
                <Link
                  key={episode.id}
                  to={`/watch/${anime.id}/${episode.number}`}
                  className="card overflow-hidden group"
                >
                  <div className="relative aspect-video bg-dark-800">
                    <img
                      src={episode.thumbnail}
                      alt={`Episode ${episode.number}`}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                      <Play size={48} className="text-white" fill="currentColor" />
                    </div>
                    <div className="absolute bottom-2 right-2 px-2 py-1 bg-black/80 rounded text-xs text-white">
                      {Math.floor(episode.duration / 60)}:{(episode.duration % 60).toString().padStart(2, '0')}
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-dark-50 mb-1">
                      Episode {episode.number}
                    </h3>
                    <p className="text-sm text-dark-400 line-clamp-1">{episode.title}</p>
                  </div>
                </Link>
              ))}
            </div>
          </div>
        )}

        {/* Related Anime */}
        {relatedAnimes.length > 0 && (
          <div className="mt-12">
            <h2 className="font-display font-bold text-2xl text-white mb-6">
              More Like This
            </h2>
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {relatedAnimes.map((relatedAnime) => (
                <AnimeCard key={relatedAnime.id} anime={relatedAnime} />
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
