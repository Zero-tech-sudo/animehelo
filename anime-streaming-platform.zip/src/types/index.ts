// Core Types for Anime Streaming Platform

export interface Anime {
  id: string;
  title: string;
  alternativeTitles?: string[];
  synopsis: string;
  fullSynopsis: string;
  posterImage: string;
  bannerImage: string;
  releaseYear: number;
  status: 'ongoing' | 'completed' | 'upcoming';
  type: 'TV' | 'Movie' | 'OVA' | 'ONA' | 'Special';
  genres: string[];
  studio: string;
  episodeCount: number;
  duration: number; // in minutes
  language: ('sub' | 'dub')[];
  popularity: number;
  views: number;
  lastUpdated: string;
}

export interface Episode {
  id: string;
  animeId: string;
  number: number;
  title: string;
  synopsis?: string;
  duration: number; // in seconds
  airDate: string;
  thumbnail: string;
  streamAssets: VideoAsset[];
  subtitleTracks: SubtitleTrack[];
}

export interface VideoAsset {
  id: string;
  quality: '360p' | '480p' | '720p' | '1080p' | '4K';
  codec: string;
  fileSize: number; // in bytes
  streamUrl: string;
  downloadable: boolean;
  downloadUrl?: string;
}

export interface SubtitleTrack {
  id: string;
  language: string;
  format: 'vtt' | 'srt';
  url: string;
}

export interface WatchProgress {
  userId: string;
  episodeId: string;
  timestamp: number; // in seconds
  completed: boolean;
  lastWatched: string;
}

export interface User {
  id: string;
  username: string;
  email: string;
  avatar?: string;
  role: 'user' | 'admin' | 'moderator';
  preferences: UserPreferences;
  createdAt: string;
}

export interface UserPreferences {
  defaultLanguage: 'sub' | 'dub';
  autoPlay: boolean;
  defaultQuality: string;
  theme: 'dark' | 'light';
}

export interface FilterOptions {
  genres: string[];
  status: Anime['status'][];
  type: Anime['type'][];
  year: number[];
  language: ('sub' | 'dub')[];
}

export interface SearchParams {
  query?: string;
  genres?: string[];
  status?: Anime['status'];
  type?: Anime['type'];
  year?: number;
  language?: 'sub' | 'dub';
  sortBy?: 'popularity' | 'views' | 'recent' | 'title' | 'year';
  sortOrder?: 'asc' | 'desc';
}
